"""
evaluate.py - Evaluación y Pruebas de Estrés
=============================================
Uso:
    python scripts/evaluate.py --model outputs/models/ppo_final.zip
    python scripts/evaluate.py --model outputs/models/ppo_final.zip --stress

TODO (Fase 4): Implementar evaluación completa con escenarios de cópulas.
"""

import argparse
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description="TSC Framework - Evaluación y Pruebas de Estrés"
    )
    parser.add_argument(
        "--config",
        type=str,
        default="config/default_config.yaml",
        help="Ruta al archivo de configuración YAML",
    )
    parser.add_argument(
        "--model",
        type=str,
        required=True,
        help="Ruta al modelo entrenado (.zip de stable-baselines3)",
    )
    parser.add_argument(
        "--n-episodes",
        type=int,
        default=20,
        help="Número de episodios de evaluación",
    )
    parser.add_argument(
        "--stress",
        action="store_true",
        help="Usar escenarios de estrés generados por cópulas",
    )
    parser.add_argument(
        "--render",
        action="store_true",
        help="Usar sumo-gui para visualizar la evaluación",
    )
    return parser.parse_args()


def main() -> None:
    args = parse_args()
    print(f"[TSC-Evaluate] Modelo: {args.model}")
    print(f"[TSC-Evaluate] Episodios: {args.n_episodes} | Stress: {args.stress}")
    print("[TSC-Evaluate] ⚙️  Fase 0 - Andamiaje completado. Lógica pendiente (Fase 4).")
    # TODO: Cargar modelo desde args.model
    # TODO: Inicializar entorno (modo stress si --stress activo)
    # TODO: Ejecutar N episodios y recopilar métricas
    # TODO: Calcular CVaR, Gini, delay promedio, throughput
    # TODO: Generar reporte en outputs/results/


if __name__ == "__main__":
    main()
